# Draughts Board > 70-20-10-split-augmented
https://universe.roboflow.com/object-detection/draughts-board-fm9sx

Provided by Roboflow
License: Public Domain

This dataset was created by [Harry Field](https://www.linkedin.com/in/harry-field-16308ba7) and contains the labelled images for capturing the game state of a draughts/checkers 8x8 board.

This was a fun project to develop a mobile draughts applciation enabling users to interact with draughts-based software via their mobile device's camera.

The data captured consists of:
* White Pieces
* White Kings
* Black Pieces
* Black Kings
* Bottom left corner square
* Top left corner square
* Top right corner square
* Bottom right corner square

Corner squares are captured so the board locations of the detected pieces can be estimated.

![Results of Yolov5 model after training with this dataset](https://github.com/ShippingTycoon/roboflow-draughts/blob/main/PXL_20210603_093949805_jpg.rf.30e2a64a0a646e8ea8e121727cf0f1ee.jpg?raw=true)

From this data, the locations of other squares can be estimated and game state can be captured. The image below shows the data of a different board configuration being captured. Blue circles refer to squares, numbers refer to square index and the coloured circles refer to pieces.
![](https://github.com/ShippingTycoon/roboflow-draughts/blob/main/pieces.png?raw=true)

Once game state is captured, integration with other software becomes possible. In this example, I created a simple move suggestion mobile applciation seen working [here](https://youtu.be/zBwPSSCmlIQ).

The developed application is a proof of concept and is not available to the public. Further development is required in training the model accross multiple draughts boards and implementing features to add vlaue to the physical draughts game.

The dataset consists of 759 images and was trained using Yolov5 with a 70/20/10 split.

The output of Yolov5 was parsed and filtered to correct for duplicated/overlapping detections before game state could be determined.

I hope you find this dataset useful and if you have any questions feel free to drop me a message on LinkedIn as per the link above.

